
const container = document.querySelector('#container');
const button = document.querySelector('#changeText');

button.addEventListener('click', function() {
    container.innerHTML = ('<h1>Bye!</h1>');
});