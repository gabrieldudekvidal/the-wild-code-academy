
const button1 = document.querySelector('.btn1');
const button2 = document.querySelector('#btn2');

button1.addEventListener('click', function() {
    // Use the callback to perform action when clicked
    alert("By class was clicked!");
});

button2.addEventListener('click', function() {
    alert("By id was clicked!");
});